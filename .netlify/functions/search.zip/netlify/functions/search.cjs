var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/search.js
var search_exports = {};
__export(search_exports, {
  default: () => search_default
});
module.exports = __toCommonJS(search_exports);
var import_blobs = require("@netlify/blobs");
var search_default = async (req) => {
  const q = new URL(req.url).searchParams.get("q")?.toLowerCase();
  if (!q) {
    return new Response(JSON.stringify([]));
  }
  const store = (0, import_blobs.getStore)("vehicle_tokens");
  const results = [];
  for await (const key of store.keys()) {
    const item = JSON.parse(await store.get(key));
    if (item.receipt_no.toLowerCase().includes(q) || item.car.toLowerCase().includes(q)) {
      results.push(item);
    }
  }
  return new Response(JSON.stringify(results), {
    headers: { "Content-Type": "application/json" }
  });
};
