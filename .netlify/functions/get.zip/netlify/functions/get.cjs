var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/get.js
var get_exports = {};
__export(get_exports, {
  default: () => get_default
});
module.exports = __toCommonJS(get_exports);
var import_blobs = require("@netlify/blobs");
var get_default = async (req) => {
  const id = new URL(req.url).searchParams.get("id");
  if (!id) {
    return new Response("Missing id", { status: 400 });
  }
  const store = (0, import_blobs.getStore)("vehicle_tokens");
  const item = await store.get(id);
  if (!item) {
    return new Response("Not found", { status: 404 });
  }
  return new Response(item, {
    headers: { "Content-Type": "application/json" }
  });
};
