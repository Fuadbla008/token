var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/list.js
var list_exports = {};
__export(list_exports, {
  default: () => list_default
});
module.exports = __toCommonJS(list_exports);
var import_blobs = require("@netlify/blobs");
var list_default = async () => {
  const store = (0, import_blobs.getStore)("vehicle_tokens");
  const records = [];
  for await (const key of store.keys()) {
    const item = await store.get(key);
    records.push(JSON.parse(item));
  }
  records.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  return new Response(JSON.stringify(records), {
    headers: { "Content-Type": "application/json" }
  });
};
